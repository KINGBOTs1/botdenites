let handler = async m => {

let krtu = `web`
m.reply(`
> https://botcahx.ddns.net
`.trim()) 
}
handler.command = /^(web)$/i

module.exports = handler
