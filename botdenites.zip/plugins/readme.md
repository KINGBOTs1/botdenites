- Kalo masalah sesi lu ambil di Sc sebelah karena sc ini tidak bisa scan session
- Scan qr ada di module readme main baca aja readme nya

- Free apikey
[Link](https://botcahx.ddns.net)

- Downloader api
[Link](https://botcahx2.ddns.net)
