## Panel Pterodaktyl
> Deploy bot mudah dan cepat di panel 

- Free 
- Runtime 24/7
- No delay !
- Server selalu up-to-date 

## Panel Pterodaktyl
**Register Here** 

[`Panel Server 1`](https://bit.ly/3BO4gvS)

> **Warning**: 
> Run bot anti banned dan delay cukup pencet button start dan bot otomatis berjalan.
